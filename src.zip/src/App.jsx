import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { useState } from "react";
import './App.css'
import Header from './components/Header';
import Main from './components/Main';
import About from './components/About';
import Contact from './components/Contact';
import AddTenants from "./components/AddTenants";
import AllTenants from "./components/AllTenants";
import Login from "./components/Login";
import Signup from "./components/Signup";
import Footer from './components/Footer';
import UpdateTenants from "./components/UpdateTenants";
import Landing from "./components/Landing";

function App() {
    const [isAuthenticated, setIsAuthenticated] = useState(false);

    return (
        <>
            <BrowserRouter>
                {!isAuthenticated ? (
                    <Routes>
                        <Route path="*" element={<Landing setIsAuthenticated={setIsAuthenticated} />} />
                        <Route path="/login" element={<Login setIsAuthenticated={setIsAuthenticated} />} />
                        <Route path="/signup" element={<Signup setIsAuthenticated={setIsAuthenticated} />} />
                    </Routes>
                ) : (
                    <>
                        <Header />
                        <Routes>
                            <Route path="/" element={<Main />} />
                            <Route path="/about" element={<About />} />
                            <Route path="/contact" element={<Contact />} />
                            <Route path="/add-tenant" element={<AddTenants />} />
                            <Route path="/all-tenants" element={<AllTenants />} />
                            <Route path="/update/:id" element={<UpdateTenants />} />
                        </Routes>
                        <Footer />
                    </>
                )}
            </BrowserRouter>
        </>
    );
}

export default App;
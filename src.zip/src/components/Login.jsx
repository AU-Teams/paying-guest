import './Login.css'
import React, { useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';

const Login=({ setIsAuthenticated })=>{
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const loginHandler = async (e) => {
    e.preventDefault();
    setError('');
    if (!username || !password) {
      setError("Please fill in all fields.");
      return;
    }

    try {
      const res = await axios.get(`http://localhost:3000/users?username=${username}&password=${password}`);
      if (res.data.length > 0) {
        alert("Login successful!");
        setIsAuthenticated(true);
        navigate('/');
      } else {
        setError("Invalid username or password.");
      }
    } catch (err) {
      console.error("Login error:", err);
      setError("Something went wrong. Try again.");
    }
  };

  return (
    <div className="login-container">
      <h2>User Login</h2>
      {error && <div className="error">{error}</div>}
      <form onSubmit={loginHandler} className="login-form">
        <label>Username</label>
        <input
          type="text"
          placeholder="Enter username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <label>Password</label>
        <input
          type="password"
          placeholder="Enter password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button type="submit">Login</button>

        <div className="extra-links">
          <p><Link to="/forgot-password">Forgot Password?</Link></p>
          <p>Don't have an account? <Link to="/Signup">Sign up</Link></p>
        </div>
      </form>
    </div>
  );
};

export default Login;

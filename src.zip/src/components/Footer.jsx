function Footer() {
    return (
        <footer className="footer">
            <div className="footer-section">
                <div className="footer-logo">Paying Guest</div>
                <div className="footer-links">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms of Service</a>
                    <a href="#">Contact Us</a>
                </div>
            </div>
            <div className="copy-right">
                <p>&copy; 2023 Paying Guest. All rights reserved.</p>
            </div>
        </footer>
    )
}

export default Footer;
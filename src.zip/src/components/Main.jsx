function Main() {
    return (
        <section className="hero">
            <div className="hero-container">
                <div>Welcome</div>
                <div>Paying Guest</div>
            </div>
        </section>
    )
}

export default Main;
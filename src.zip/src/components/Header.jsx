import {Link} from 'react-router-dom';
import './Header.css'

function Header() {
    return (
        <header className='header'>
            <div className="header-section">
                <div className="logo">Paying Guest</div>
                <nav className="header-nav">
                    <Link to="/">Home</Link>
                    <Link to="about">About</Link>
                    <Link to="contact">Contact</Link>
                    <Link to="add-tenant">AddTenant</Link>
                    <Link to="all-tenants">AllTenants</Link>
                    <Link to="profile">Profile</Link>
                </nav>
            </div>
        </header>
    )
}

export default Header;
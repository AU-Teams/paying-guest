import './AddTenants.css'
import React, { useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
const AddTenants = () => {
  const[name, setName] = useState('');
  const[room, setRoom] = useState('');
  const[address, setAddress] = useState('');

  const navigate = useNavigate();

  const nameHandler =(e)=>{
    e.preventDefault();
    setName(e.target.value);
  }
  const roomHandler =(e)=>{
    e.preventDefault();
    setRoom(e.target.value);
  }
  const addressHandler =(e)=>{
    e.preventDefault();
    setAddress(e.target.value);
  }
  const btnHandler =(e)=>{
    e.preventDefault();
    const playload = {name,room,address};
    axios.post('http://localhost:3000/content',playload)
    .then(()=>{
      alert('data saved successfully !!!')
      console.log("data saved")
      setName('')
      setRoom('')
      setAddress('')
    })
    .catch(()=>{
      console.log('error')
    })
    navigate('./AddTenants.jsx')
  }
  return(
    <div className='Add-Tenants'>
      <h1>Add Tenants</h1>
      <form action="">
        <label htmlFor="">Name</label>
        <input type="text" value={name} onChange={nameHandler} placeholder='Enter Tenant Name'></input>
        <label htmlFor="">Room Number</label>
        <input type="number" value={room} onChange={roomHandler} placeholder='Enter Tenant Room number'></input>
        <label htmlFor="">Address</label>
        <input type="text" value={address} onChange={addressHandler} placeholder='Enter Tenant Address'></input>
        <button onClick={btnHandler}>Submit</button>
      </form>
    </div>
  );
}

export default AddTenants;
import React, { useState } from 'react'
import './AddTenants.css'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import { useParams } from 'react-router-dom'
import { useEffect } from 'react'
const UpdateTenants = () => {
  const[name, setName] = useState('');
  const[room, setRoom] = useState('');
  const[address, setAddress] = useState('');
  const navigate = useNavigate();

  const {id} =  useParams();
  const nameHandler =(e)=>{
    e.preventDefault();
    setName(e.target.value);
  }
  const roomHandler =(e)=>{
    e.preventDefault();
    setRoom(e.target.value);
  }
  const addressHandler =(e)=>{
    e.preventDefault();
    setAddress(e.target.value);
  }
  useEffect(()=>{
    axios.get(`http://localhost:3000/content/${id}`)
    .then((res)=>{
        setName(res.data.name);
        setRoom(res.data.room);
        setAddress(res.data.address);
    })
    .catch((err)=>{
        console.log(err)
    })
  },[])
  const updateHandler =(e)=>{
    e.preventDefault();
    const playload = {name,room,address};
    axios.put(`http://localhost:3000/content/${id}`,playload)
    .then(()=>{
      alert('Updated successfully !!!')
      console.log("Updated")
      setName('')
      setRoom('')
      setAddress('')
      navigate('all-tenants')
    })
    .catch(()=>{
      console.log('error')
    })
  }
  return(
    <div className='Add-Tenants'>
      <h2>Update Tenants</h2>
      <form action="">
        <label htmlFor="">Name</label>
        <input type="text" value={name} onChange={nameHandler} placeholder='Update Tenant Name'></input>
        <label htmlFor="">Room Number</label>
        <input type="number" value={room} onChange={roomHandler} placeholder='Update Tenant Room number'></input>
        <label htmlFor="">Address</label>
        <input type="text" value={address} onChange={addressHandler} placeholder='Update Tenant Address'></input>
        <button onClick={updateHandler}>Update</button>
      </form>
    </div>
  )
}

export default UpdateTenants;